/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8898305084745762, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Delete Contact"], "isController": true}, {"data": [1.0, 500, 1500, "PUT Update Contact Request - 4"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "POST Auth Request"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Contact Request - 2"], "isController": false}, {"data": [1.0, 500, 1500, "PUT Update Contact Request - 3"], "isController": false}, {"data": [0.5, 500, 1500, "GET Contact by List and ID - 2"], "isController": true}, {"data": [1.0, 500, 1500, "GET Contact by ID Request - 3"], "isController": false}, {"data": [1.0, 500, 1500, "GET Contact by ID Request - 2"], "isController": false}, {"data": [0.5, 500, 1500, "GET Contact by List and ID - 3"], "isController": true}, {"data": [1.0, 500, 1500, "GET Contact by ID Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "GET Contact by List and ID - 1"], "isController": true}, {"data": [1.0, 500, 1500, "GET Contact by ID Request - 4"], "isController": false}, {"data": [1.0, 500, 1500, "GET Contact by ID Request - 1"], "isController": false}, {"data": [0.5, 500, 1500, "GET Contact by List and ID - 4"], "isController": true}, {"data": [0.5, 500, 1500, "GET Contact by List and ID - 5"], "isController": true}, {"data": [1.0, 500, 1500, "PUT Update Contact Request - 1"], "isController": false}, {"data": [1.0, 500, 1500, "POST Add Contact Request - 2"], "isController": false}, {"data": [1.0, 500, 1500, "DEL Delete Contact Request - 1"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact Request - 4"], "isController": false}, {"data": [1.0, 500, 1500, "POST Add Contact Request - 1"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact Request - 3"], "isController": false}, {"data": [1.0, 500, 1500, "DEL Delete Contact Request - 3"], "isController": false}, {"data": [1.0, 500, 1500, "DEL Delete Contact Request - 2"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "GET List Contact Request - 4"], "isController": false}, {"data": [0.5, 500, 1500, "GET List Contact Request - 5"], "isController": false}, {"data": [0.5, 500, 1500, "GET List Contact Request - 2"], "isController": false}, {"data": [0.5, 500, 1500, "GET List Contact Request - 3"], "isController": false}, {"data": [1.0, 500, 1500, "GET List Contact Request - 1"], "isController": false}, {"data": [1.0, 500, 1500, "Add Contact"], "isController": true}, {"data": [1.0, 500, 1500, "PUT Update Contact"], "isController": true}, {"data": [1.0, 500, 1500, "DEL Delete Contact Request - 5"], "isController": false}, {"data": [1.0, 500, 1500, "POST Add Contact Request - 5"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact"], "isController": true}, {"data": [1.0, 500, 1500, "DEL Delete Contact Request - 4"], "isController": false}, {"data": [1.0, 500, 1500, "POST Add Contact Request - 4"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact Request - 2"], "isController": false}, {"data": [1.0, 500, 1500, "POST Add Contact Request - 3"], "isController": false}, {"data": [1.0, 500, 1500, "PATCH Update Contact Request - 1"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 34, 0, 0.0, 413.9117647058823, 260, 1099, 282.0, 1084.5, 1098.25, 1099.0, 9.004237288135593, 34.60822671146716, 5.691011073225636], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Delete Contact", 5, 0, 0.0, 291.2, 269, 340, 279.0, 340.0, 340.0, 340.0, 3.3112582781456954, 2.454987582781457, 1.9854615066225165], "isController": true}, {"data": ["PUT Update Contact Request - 4", 1, 0, 0.0, 270.0, 270, 270, 270.0, 270.0, 270.0, 270.0, 3.7037037037037037, 3.960503472222222, 3.490306712962963], "isController": false}, {"data": ["PUT Update Contact Request - 5", 1, 0, 0.0, 275.0, 275, 275, 275.0, 275.0, 275.0, 275.0, 3.6363636363636362, 3.888494318181818, 3.426846590909091], "isController": false}, {"data": ["POST Auth Request", 4, 0, 0.0, 1091.5, 1081, 1099, 1093.0, 1099.0, 1099.0, 1099.0, 2.1834061135371177, 2.6908774563318776, 0.5863639465065502], "isController": false}, {"data": ["PUT Update Contact Request - 2", 1, 0, 0.0, 410.0, 410, 410, 410.0, 410.0, 410.0, 410.0, 2.4390243902439024, 2.598608993902439, 2.2984946646341466], "isController": false}, {"data": ["PUT Update Contact Request - 3", 1, 0, 0.0, 285.0, 285, 285, 285.0, 285.0, 285.0, 285.0, 3.5087719298245617, 3.752055921052632, 3.3066063596491233], "isController": false}, {"data": ["GET Contact by List and ID - 2", 1, 0, 0.0, 784.0, 784, 784, 784.0, 784.0, 784.0, 784.0, 1.2755102040816326, 26.72343351403061, 1.3365453603316326], "isController": true}, {"data": ["GET Contact by ID Request - 3", 1, 0, 0.0, 482.0, 482, 482, 482.0, 482.0, 482.0, 482.0, 2.074688796680498, 2.175991960580913, 1.112308739626556], "isController": false}, {"data": ["GET Contact by ID Request - 2", 1, 0, 0.0, 263.0, 263, 263, 263.0, 263.0, 263.0, 263.0, 3.802281368821293, 3.9879396387832697, 2.0385278041825092], "isController": false}, {"data": ["GET Contact by List and ID - 3", 1, 0, 0.0, 1008.0, 1008, 1008, 1008.0, 1008.0, 1008.0, 1008.0, 0.992063492063492, 21.10653831845238, 1.0395352802579365], "isController": true}, {"data": ["GET Contact by ID Request - 5", 1, 0, 0.0, 285.0, 285, 285, 285.0, 285.0, 285.0, 285.0, 3.5087719298245617, 3.7006578947368425, 1.881167763157895], "isController": false}, {"data": ["GET Contact by List and ID - 1", 1, 0, 0.0, 536.0, 536, 536, 536.0, 536.0, 536.0, 536.0, 1.8656716417910448, 38.51591651119403, 1.9549469449626864], "isController": true}, {"data": ["GET Contact by ID Request - 4", 1, 0, 0.0, 277.0, 277, 277, 277.0, 277.0, 277.0, 277.0, 3.6101083032490977, 3.8145870938628157, 1.9354975180505414], "isController": false}, {"data": ["GET Contact by ID Request - 1", 1, 0, 0.0, 260.0, 260, 260, 260.0, 260.0, 260.0, 260.0, 3.8461538461538463, 4.071514423076923, 2.0620492788461537], "isController": false}, {"data": ["GET Contact by List and ID - 4", 1, 0, 0.0, 801.0, 801, 801, 801.0, 801.0, 801.0, 801.0, 1.2484394506866416, 26.976777075530585, 1.3081792290886392], "isController": true}, {"data": ["GET Contact by List and ID - 5", 1, 0, 0.0, 814.0, 814, 814, 814.0, 814.0, 814.0, 814.0, 1.2285012285012284, 26.541145193488944, 1.2872869318181819], "isController": true}, {"data": ["PUT Update Contact Request - 1", 1, 0, 0.0, 268.0, 268, 268, 268.0, 268.0, 268.0, 268.0, 3.7313432835820897, 3.975483908582089, 3.516353777985074], "isController": false}, {"data": ["POST Add Contact Request - 2", 1, 0, 0.0, 269.0, 269, 269, 269.0, 269.0, 269.0, 269.0, 3.717472118959108, 3.9171410315985127, 3.165659851301115], "isController": false}, {"data": ["DEL Delete Contact Request - 1", 1, 0, 0.0, 340.0, 340, 340, 340.0, 340.0, 340.0, 340.0, 2.941176470588235, 2.1714154411764706, 1.7635569852941175], "isController": false}, {"data": ["PATCH Update Contact Request - 4", 1, 0, 0.0, 307.0, 307, 307, 307.0, 307.0, 307.0, 307.0, 3.257328990228013, 3.4768169788273617, 2.0771834283387625], "isController": false}, {"data": ["POST Add Contact Request - 1", 1, 0, 0.0, 270.0, 270, 270, 270.0, 270.0, 270.0, 270.0, 3.7037037037037037, 3.938802083333333, 3.1901041666666665], "isController": false}, {"data": ["PATCH Update Contact Request - 3", 1, 0, 0.0, 295.0, 295, 295, 295.0, 295.0, 295.0, 295.0, 3.389830508474576, 3.6182468220338984, 2.161679025423729], "isController": false}, {"data": ["DEL Delete Contact Request - 3", 1, 0, 0.0, 269.0, 269, 269, 269.0, 269.0, 269.0, 269.0, 3.717472118959108, 2.7590613382899627, 2.2290311338289963], "isController": false}, {"data": ["DEL Delete Contact Request - 2", 1, 0, 0.0, 272.0, 272, 272, 272.0, 272.0, 272.0, 272.0, 3.676470588235294, 2.7286305147058822, 2.2044462316176467], "isController": false}, {"data": ["PATCH Update Contact Request - 5", 1, 0, 0.0, 299.0, 299, 299, 299.0, 299.0, 299.0, 299.0, 3.3444816053511706, 3.5698421822742477, 2.1327602424749164], "isController": false}, {"data": ["GET List Contact Request - 4", 1, 0, 0.0, 524.0, 524, 524, 524.0, 524.0, 524.0, 524.0, 1.9083969465648853, 39.22091185591603, 0.9765625], "isController": false}, {"data": ["GET List Contact Request - 5", 1, 0, 0.0, 529.0, 529, 529, 529.0, 529.0, 529.0, 529.0, 1.890359168241966, 38.846511696597354, 0.9673322306238185], "isController": false}, {"data": ["GET List Contact Request - 2", 1, 0, 0.0, 521.0, 521, 521, 521.0, 521.0, 521.0, 521.0, 1.9193857965451055, 38.20027591170825, 0.9821857005758157], "isController": false}, {"data": ["GET List Contact Request - 3", 1, 0, 0.0, 526.0, 526, 526, 526.0, 526.0, 526.0, 526.0, 1.9011406844106464, 38.45354087452471, 0.9728493346007604], "isController": false}, {"data": ["GET List Contact Request - 1", 1, 0, 0.0, 276.0, 276, 276, 276.0, 276.0, 276.0, 276.0, 3.6231884057971016, 70.96354166666666, 1.8540534420289854], "isController": false}, {"data": ["Add Contact", 5, 0, 0.0, 269.8, 269, 271, 270.0, 271.0, 271.0, 271.0, 4.205214465937763, 4.447507096299411, 3.5974295626576955], "isController": true}, {"data": ["PUT Update Contact", 5, 0, 0.0, 301.6, 268, 410, 275.0, 410.0, 410.0, 410.0, 3.401360544217687, 3.6318824404761907, 3.2053837159863945], "isController": true}, {"data": ["DEL Delete Contact Request - 5", 1, 0, 0.0, 279.0, 279, 279, 279.0, 279.0, 279.0, 279.0, 3.5842293906810037, 2.660170250896057, 2.1491375448028673], "isController": false}, {"data": ["POST Add Contact Request - 5", 1, 0, 0.0, 271.0, 271, 271, 271.0, 271.0, 271.0, 271.0, 3.6900369003690034, 3.89543934501845, 3.1495041512915125], "isController": false}, {"data": ["PATCH Update Contact", 5, 0, 0.0, 290.2, 271, 307, 295.0, 307.0, 307.0, 307.0, 3.331112591605596, 3.5529698950699538, 2.124234885076616], "isController": true}, {"data": ["DEL Delete Contact Request - 4", 1, 0, 0.0, 296.0, 296, 296, 296.0, 296.0, 296.0, 296.0, 3.3783783783783785, 2.5073902027027026, 2.0257073479729732], "isController": false}, {"data": ["POST Add Contact Request - 4", 1, 0, 0.0, 270.0, 270, 270, 270.0, 270.0, 270.0, 270.0, 3.7037037037037037, 3.9315682870370368, 3.1828703703703702], "isController": false}, {"data": ["PATCH Update Contact Request - 2", 1, 0, 0.0, 279.0, 279, 279, 279.0, 279.0, 279.0, 279.0, 3.5842293906810037, 3.8257448476702507, 2.285646281362007], "isController": false}, {"data": ["POST Add Contact Request - 3", 1, 0, 0.0, 269.0, 269, 269, 269.0, 269.0, 269.0, 269.0, 3.717472118959108, 3.9171410315985127, 3.165659851301115], "isController": false}, {"data": ["PATCH Update Contact Request - 1", 1, 0, 0.0, 271.0, 271, 271, 271.0, 271.0, 271.0, 271.0, 3.6900369003690034, 3.924267758302583, 2.353119234317343], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 34, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
